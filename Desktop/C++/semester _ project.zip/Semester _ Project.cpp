#include <iostream>
#include <cstdlib>
#include <ctime>

int main() {
    srand(time(0)); // Seed the random number generator with current time
    int randomNumber = rand() % 100 + 1; // Generate a random number between 1 and 100

    int playerGuess;
    int money = 100; // Initial amount of money

    std::cout << "Welcome to the Casino Number Guessing Game!" << std::endl;
    std::cout << "You have $" << money << ". Guess a number between 1 and 100." << std::endl;

    do {
        std::cout << "Enter your guess: ";
        std::cin >> playerGuess;

        if (playerGuess == randomNumber) {
            std::cout << "Congratulations! You guessed the correct number and won $100!" << std::endl;
            money += 100;
        } else {
            std::cout << "Sorry, that's incorrect. The correct number was " << randomNumber << "." << std::endl;
            money -= 10;
        }

        std::cout << "You now have $" << money << "." << std::endl;

        if (money <= 0) {
            std::cout << "You've run out of money. Game over!" << std::endl;
            break;
        }

        char playAgain;
        std::cout << "Do you want to play again? (y/n): ";
        std::cin >> playAgain;

        if (playAgain != 'y' && playAgain != 'Y') {
            break;
        }

        randomNumber = rand() % 100 + 1;

    } while (true);

    std::cout << "Thank you for playing the Casino Number Guessing Game!" << std::endl;

    return 0;
}
